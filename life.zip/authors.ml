(* write the hours you've worked next to your name *)
let allison = 8
let enyu = 7
let iris = 8
let janice = 12

let hours_worked = 
  allison + enyu + iris + janice